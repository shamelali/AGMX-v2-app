# AGMX — Phase 2 Release Security Audit

Reviewed GitHub repository: `shamelali/AGMX-v2-app`, branch `main` at commit `2e78b731bc95fa5a9bb621ec510db0fa911ae0db` (as available 2026-11-19). Audit is **source review**, not live penetration testing or a deployment attestation.

## Release decision: NO-GO for unrestricted customer launch

The user's local verification reports a live website, local health tests and local money-flow tests passing. The latest GitHub Actions workflow run #44343383666 is still `failure`. An accessible website or passing demo adapter tests do not establish payment security, tenant isolation or ballot integrity.

## Confirmed source findings

1. **Payment feature readiness mismatch (P1)** — `api/config.js` originally enables gateway presentation when `HITPAY_API_KEY` alone exists or Billplz has an API key and collection ID. But `supabase/functions/money-flow/index.ts` requires `HITPAY_SALT` / `BILLPLZ_X_SIGNATURE` for callback verification. Apply `payment-readiness.patch`, and test the route and checkout display in staging. *This patch only modifies Vercel-side UI readiness; Supabase Edge secrets remain a separate deployment scope.*

2. **Caller-controlled payment URLs (P1, needs remediation/design validation)** — `supabase/functions/money-flow/index.ts` lines 698 and 705 use `input.callbackUrl` and `input.returnUrl` supplied by authenticated user or checkout-token holder. The callback URL for Billplz can be overridden, leading to misrouted payment notifications; return URLs can redirect customers to arbitrary sites. Replace arbitrary callback selection with a server-computed canonical callback; permit only allowlisted return URLs. Carefully test compatibility with the gateway's actual callback URL and signature formats before shipping.

3. **Manual payment settlement is multiple writes (P1, transaction robustness)** — `handlePaymentManualConfirm` separately updates payment, invoice and assessment, without checking each write's error before returning success. Replace with a single operator-authorized transactional RPC that checks payment method/status, records actor, and is idempotent. Regression test partial failure and duplicate confirmations.

4. **Production settlement is not covered by local adapter tests (P0 verification gap)** — `tools/test_money_flow.mjs` explicitly tests `AGMX_COMMERCE` LocalAdapter (`api.js`) in-memory. Real settlement goes through Edge Function `/payment/confirm`, its gateway signature logic, and `process_payment_webhook` RPC. Execute staging tests: valid/invalid signatures, replay, wrong invoice, cross-tenant references, amount/currency/gateway reference mismatch, timeout and duplicate events. No real card details or production payments in testing.

5. **Governance ballot controls need adversarial testing (P0 verification gap)** — `governance/index.ts` derives member ID from session and checks motion tenant, `cast_vote` SQL checks quorum and duplicate vote uniqueness; these are positive patterns. Verify with 2 tenants, nonmember, ineligible member, duplicate simultaneous requests, quorum change, anonymous vs authenticated direct RPC, ballot reading and audit integrity. `tools/test_production_ballot_path.mjs` is a read-only proof of function presence and guards, not a full adversarial suite.

6. **CI remains red (P0)** — latest Actions workflow run #44343383666 shows `Lint & Test` and `Verify Deploy Author` failed and deployment skipped; job-step logs were unavailable through connector. Preserve `.github/workflows/deploy.yml` security and release gating. Resolve runner/Actions failure and demand green CI on the candidate commit, rather than assuming no code failure from empty step data.

7. **CSP hardening (P2)** — `vercel.json` has `script-src 'self' 'unsafe-inline' https://esm.sh`. Migrate using a tested Content Security Policy report-only phase before removing inline allowance; immediate removal may break existing pages.

## Evidence and signoff gates

- [ ] Local branch based on current `origin/main`, clean diff, reviewed PR
- [ ] `node tools/test_health.js` passes
- [ ] `node tools/test_money_flow.mjs` passes (local adapter only)
- [ ] `AGMX_SKIP_NET=1 bash tools/check.sh` passes with Node 24 / Deno 2
- [ ] GitHub Actions Lint & Test and Verify Deploy Author green for exact release SHA
- [ ] Staging tenant-isolation test matrix green, including service-role boundary
- [ ] Staging e-voting integrity, secrecy and duplicate vote checks green
- [ ] Staging payment gateway + webhook + manual settlement tests green
- [ ] Production secrets present in correct Vercel/Supabase scopes, no secrets printed
- [ ] Domain `www.agmx.my` canonical, auth redirect and payment callbacks verified
- [ ] Monitoring, backups, restore drill, rollback steps documented
- [ ] Production release owner approves PR and deploy

## Safe local sequence

```bash
cd ~/projects/AGMX-v2-app
git fetch origin
git status --short --branch
git switch -c audit/phase2-payment-readiness origin/main
# Transfer extracted files to repo root, then:
git apply --check payment-readiness.patch
git apply payment-readiness.patch
cp test_payment_readiness.mjs tools/test_payment_readiness.mjs
node tools/test_payment_readiness.mjs
node tools/test_health.js
node tools/test_money_flow.mjs
AGMX_SKIP_NET=1 bash tools/check.sh
git diff --check
git add api/config.js tools/test_payment_readiness.mjs
git commit -m 'fix: require verifiable payment gateway readiness'
git push -u origin audit/phase2-payment-readiness
# Open PR. Never push or merge to main without green CI and approval.
```

**Important:** move or copy `payment-readiness.patch` and `test_payment_readiness.mjs` into the repository root before using these commands. This package makes no repository or production change on its own.
